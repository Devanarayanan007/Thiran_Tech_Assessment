const express = require('express');
const app = express();
const cors = require('cors');
app.use(cors());
app.use(express.json());

let stock = { India: 100, Srilanka: 100 };

app.post('/calculate-cost', (req, res) => {
    const { country, units } = req.body;

    if (!country || !units) {
        return res.status(400).json({ message: 'Invalid input. Provide country and units.' });
    }

    const unitCost = { India: 30000, Srilanka: 25000 };
    const transportCostPer10 = 5000;

    let cost = 0;
    let remainingStock = { ...stock };

    if (remainingStock[country] >= units) {
        cost = units * unitCost[country];
        remainingStock[country] -= units;
    } else {
        const localStock = remainingStock[country];
        const remainingUnits = units - localStock;

        cost = localStock * unitCost[country];
        remainingStock[country] = 0;

        const otherCountry = country === 'India' ? 'Srilanka' : 'India';
        const blocks = Math.ceil(remainingUnits / 10);
        cost += remainingUnits * unitCost[otherCountry] + blocks * transportCostPer10;
        remainingStock[otherCountry] -= remainingUnits;
    }

    stock = { ...remainingStock };
    res.json({
        minimumCost: cost,
        stockLeftIndia: stock.India,
        stockLeftSrilanka: stock.Srilanka,
    });
});

app.listen(5000, () => {
    console.log('Server running on 5000');
});
