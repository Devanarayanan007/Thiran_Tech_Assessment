import React, { useState } from 'react';
import axios from 'axios';

function App() {
    const [country, setCountry] = useState('');
    const [units, setUnits] = useState('');
    const [result, setResult] = useState(null);

    const calculateCost = async () => {
        try {
            const response = await axios.post('http://localhost:5000/calculate-cost', {
                country,
                units: parseInt(units),
            });
            setResult(response.data);
        } catch (error) {
            console.error('Error:', error);
            alert('Error calculating cost.');
        }
    };

    return (
        <div>
            <h1>Ipod Cost Calculator</h1>
            <div>
                <label>The country from which the order is being placed : </label>
                <select value={country} onChange={(e) => setCountry(e.target.value)}>
                    <option value="">Select</option>
                    <option value="India">India</option>
                    <option value="Srilanka">Srilanka</option>
                </select>
            </div>
            <div>
                <label>No of units : </label>
                <input
                    type="number"
                    value={units}
                    onChange={(e) => setUnits(e.target.value)}
                />
            </div>
            <button onClick={calculateCost}>Calculate</button>

            {result && (
                <div>
                    <h3>Result:</h3>
                    <p>Minimum Costs: Rs {result.minimumCost}</p>
                    <p>No of Stock Left in India: {result.stockLeftIndia}</p>
                    <p>No of Stock Left in Srilanka: {result.stockLeftSrilanka}</p>
                </div>
            )}
        </div>
    );
}

export default App;
