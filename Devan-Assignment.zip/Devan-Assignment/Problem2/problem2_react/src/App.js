import React, { useState } from 'react';
import axios from 'axios';

function App() {
    const [n, setN] = useState('');
    const [combinations, setCombinations] = useState([]);

    const fetchCombinations = async () => {
        try {
            const response = await axios.get(`http://localhost:5002/generate-braces/${n}`);
            setCombinations(response.data.combinations);
        } catch (error) {
            console.error('Error:', error);
            alert('Error fetching braces combinations.');
        }
    };

    return (
        <div>
            <h1>Braces Combinations</h1>
            <div>
                <label>Enter value: </label>
                <input
                    type="number"
                    value={n}
                    onChange={(e) => setN(e.target.value)}
                />
            </div>
            <button onClick={fetchCombinations}>Generate</button>

            {combinations.length > 0 && (
                <div>
                    <h3>Combinations:</h3>
                    <ul>
                        {combinations.map((combo, index) => (
                            <li key={index}>{combo}</li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
}

export default App;