const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());

app.get('/generate-braces/:n', (req, res) => {
    const n = parseInt(req.params.n);

    const generateBraces = (n) => {
        const result = [];
        const backtrack = (open, close, current) => {
            if (current.length === 2 * n) {
                result.push(current);
                return;
            }
            if (open < n) backtrack(open + 1, close, current + '(');
            if (close < open) backtrack(open, close + 1, current + ')');
        };
        backtrack(0, 0, '');
        return result;
    };

    res.json({ combinations: generateBraces(n) });
});

app.listen(5002, () => {
    console.log('Server running on 5002');
});